/**
 * Dutch Mystery Portal - SIMPLIFIED TEST Worker 
 * Version: 4.3.5 - Basic Query Test
 * Using exact same queries that work in direct database access
 */

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Session-Token, X-Admin-Key',
  'Access-Control-Max-Age': '86400',
};

export default {
  async fetch(request, env, ctx) {
    console.log('=== SIMPLIFIED TEST WORKER v4.3.5 ===');
    console.log('Request URL:', request.url);

    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: corsHeaders });
    }

    try {
      const url = new URL(request.url);
      const path = url.pathname;
      console.log('Request path:', path);

      // Health check endpoint
      if (path === '/api/health' && request.method === 'GET') {
        return await handleHealthCheck(env);
      }

      // Blog content routes - SIMPLIFIED TEST
      if (path.startsWith('/blog/') || path === '/ade-2025-guide') {
        console.log('Handling blog content request - SIMPLIFIED TEST');
        return await handleBlogContentSimplified(request, env);
      }

      // Default 404 response
      return new Response(JSON.stringify({ 
        error: 'Not Found', 
        path: path,
        version: '4.3.5-simplified-test'
      }), {
        status: 404,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });

    } catch (error) {
      console.error('=== WORKER ERROR ===');
      console.error('Error:', error.message);
      
      return new Response(JSON.stringify({
        error: 'Internal Server Error',
        message: error.message,
        version: '4.3.5-simplified-test'
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    }
  },
};

/**
 * SIMPLIFIED: Blog Content Handler - Step by step testing
 */
async function handleBlogContentSimplified(request, env) {
  console.log('=== SIMPLIFIED BLOG CONTENT HANDLER ===');
  
  try {
    const url = new URL(request.url);
    let slug = url.pathname;
    
    if (slug === '/ade-2025-guide') {
      slug = 'ade-2025-guide';
    } else if (slug.startsWith('/blog/')) {
      slug = slug.replace('/blog/', '');
    }
    
    console.log('Looking for slug:', slug);

    if (!env.DB) {
      return createTestErrorResponse('Database not configured', { slug });
    }

    console.log('Database binding exists. Testing step by step...');

    let testResults = {
      slug: slug,
      tests: []
    };

    // Test 1: Basic connection test
    try {
      const healthTest = await env.DB.prepare('SELECT 1 as test').first();
      testResults.tests.push({
        name: 'Database Connection',
        status: 'SUCCESS',
        result: healthTest
      });
    } catch (error) {
      testResults.tests.push({
        name: 'Database Connection',
        status: 'FAILED',
        error: error.message
      });
    }

    // Test 2: List all tables
    try {
      const tablesTest = await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
      testResults.tests.push({
        name: 'List Tables',
        status: 'SUCCESS',
        result: tablesTest.results
      });
    } catch (error) {
      testResults.tests.push({
        name: 'List Tables',
        status: 'FAILED',
        error: error.message
      });
    }

    // Test 3: Check table structure
    try {
      const structureTest = await env.DB.prepare('PRAGMA table_info(blog_posts)').all();
      testResults.tests.push({
        name: 'Table Structure',
        status: 'SUCCESS',
        result: structureTest.results
      });
    } catch (error) {
      testResults.tests.push({
        name: 'Table Structure',
        status: 'FAILED',
        error: error.message
      });
    }

    // Test 4: Simple SELECT without WHERE clause
    try {
      const allPostsTest = await env.DB.prepare('SELECT slug, title FROM blog_posts').all();
      testResults.tests.push({
        name: 'Simple SELECT (all posts)',
        status: 'SUCCESS',
        result: allPostsTest.results
      });
    } catch (error) {
      testResults.tests.push({
        name: 'Simple SELECT (all posts)',
        status: 'FAILED',
        error: error.message
      });
    }

    // Test 5: SELECT with slug WHERE clause
    try {
      const slugTest = await env.DB.prepare('SELECT slug, title FROM blog_posts WHERE slug = ?').bind(slug).first();
      testResults.tests.push({
        name: 'SELECT with slug filter',
        status: 'SUCCESS',
        result: slugTest
      });
    } catch (error) {
      testResults.tests.push({
        name: 'SELECT with slug filter',
        status: 'FAILED',
        error: error.message
      });
    }

    // Test 6: SELECT including published column
    try {
      const publishedTest = await env.DB.prepare('SELECT slug, title, published FROM blog_posts WHERE slug = ?').bind(slug).first();
      testResults.tests.push({
        name: 'SELECT with published column',
        status: 'SUCCESS',
        result: publishedTest
      });
    } catch (error) {
      testResults.tests.push({
        name: 'SELECT with published column',
        status: 'FAILED',
        error: error.message
      });
    }

    // Test 7: SELECT ALL columns
    try {
      const allColumnsTest = await env.DB.prepare('SELECT * FROM blog_posts WHERE slug = ?').bind(slug).first();
      testResults.tests.push({
        name: 'SELECT * (all columns)',
        status: 'SUCCESS',
        result: allColumnsTest,
        hasContent: !!(allColumnsTest && allColumnsTest.content),
        contentLength: allColumnsTest && allColumnsTest.content ? allColumnsTest.content.length : 0
      });
    } catch (error) {
      testResults.tests.push({
        name: 'SELECT * (all columns)',
        status: 'FAILED',
        error: error.message
      });
    }

    // Test 8: The problematic query that was failing
    try {
      const problematicTest = await env.DB.prepare('SELECT * FROM blog_posts WHERE slug = ? AND published = 1').bind(slug).first();
      testResults.tests.push({
        name: 'Original failing query',
        status: 'SUCCESS',
        result: problematicTest
      });
    } catch (error) {
      testResults.tests.push({
        name: 'Original failing query',
        status: 'FAILED',
        error: error.message
      });
    }

    // Check authentication
    const hasAuth = detectAuthentication(request);
    testResults.authentication = {
      userAuthenticated: hasAuth,
      methods: 'URL param, cookies, headers'
    };

    // Generate HTML response with all test results
    const htmlContent = generateTestResultsHTML(testResults, hasAuth);

    return new Response(htmlContent, {
      status: 200,
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'X-Worker-Version': '4.3.5-simplified-test',
        'X-Debug-Mode': 'true',
        ...corsHeaders,
      },
    });

  } catch (error) {
    console.error('=== SIMPLIFIED HANDLER ERROR ===');
    console.error('Error:', error.message);
    
    return createTestErrorResponse('Handler error: ' + error.message, {
      error: error.message,
      stack: error.stack
    });
  }
}

/**
 * Authentication Detection - Same as before
 */
function detectAuthentication(request) {
  const authCookie = request.headers.get('Cookie') || '';
  const sessionAuth = request.headers.get('X-Session-Token') || '';
  const urlParams = new URL(request.url).searchParams;
  
  const hasPortalAuthCookie = authCookie.includes('dutchPortalAuth=authenticated');
  const hasAdminAuthCookie = authCookie.includes('dutchAdminAuth=');
  const hasSessionCookie = authCookie.includes('dutchPortalSession=');
  const hasSessionToken = sessionAuth.length > 0;
  const hasAuthParam = urlParams.get('auth') === '1';
  
  return hasPortalAuthCookie || hasAdminAuthCookie || hasSessionCookie || hasSessionToken || hasAuthParam;
}

/**
 * Health Check Handler
 */
async function handleHealthCheck(env) {
  try {
    const result = await env.DB.prepare('SELECT 1 as health').first();
    
    return new Response(JSON.stringify({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      database: result ? 'connected' : 'disconnected',
      version: '4.3.5-simplified-test'
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    });
  } catch (error) {
    return new Response(JSON.stringify({
      status: 'unhealthy',
      error: error?.message || 'Unknown error',
      version: '4.3.5-simplified-test'
    }), {
      status: 503,
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    });
  }
}

/**
 * Test Error Response
 */
function createTestErrorResponse(message, debugData) {
  const debugHtml = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Results | Dutch Mystery Portal</title>
    <style>
        body { font-family: 'Courier New', monospace; background: #000; color: #0f0; padding: 20px; line-height: 1.6; }
        h1 { color: #ff0; text-shadow: 0 0 10px #ff0; }
        .error { color: #f00; }
        .debug-section { background: #111; border: 1px solid #333; padding: 15px; margin: 15px 0; border-radius: 5px; }
        pre { background: #222; padding: 15px; border-radius: 3px; overflow-x: auto; white-space: pre-wrap; }
    </style>
</head>
<body>
    <h1>🧪 Simplified Test Results</h1>
    <div class="debug-section">
        <p class="error">${message}</p>
        <pre>${JSON.stringify(debugData, null, 2)}</pre>
    </div>
</body>
</html>`;

  return new Response(debugHtml, {
    status: 200,
    headers: { 'Content-Type': 'text/html; charset=utf-8' }
  });
}

/**
 * Generate Test Results HTML
 */
function generateTestResultsHTML(testResults, hasAuth) {
  const testSummary = testResults.tests.map(test => `
    <div class="test-result ${test.status.toLowerCase()}">
        <h3>${test.name}: <span class="status">${test.status}</span></h3>
        ${test.status === 'SUCCESS' 
          ? `<pre>${JSON.stringify(test.result, null, 2)}</pre>` 
          : `<p class="error">Error: ${test.error}</p>`
        }
        ${test.hasContent !== undefined ? `<p><strong>Has Content:</strong> ${test.hasContent}</p>` : ''}
        ${test.contentLength !== undefined ? `<p><strong>Content Length:</strong> ${test.contentLength} characters</p>` : ''}
    </div>
  `).join('');

  return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Test Results | Dutch Mystery Portal</title>
    <style>
        body { font-family: 'Courier New', monospace; background: #000; color: #0f0; padding: 20px; line-height: 1.6; }
        h1 { color: #ff0; text-shadow: 0 0 10px #ff0; text-align: center; }
        h2 { color: #0ff; text-shadow: 0 0 5px #0ff; }
        h3 { color: #fff; margin-bottom: 10px; }
        .test-result { background: #111; border: 1px solid #333; padding: 15px; margin: 15px 0; border-radius: 5px; }
        .test-result.success { border-left: 4px solid #0f0; }
        .test-result.failed { border-left: 4px solid #f00; }
        .status { font-weight: bold; }
        .success .status { color: #0f0; }
        .failed .status { color: #f00; }
        .error { color: #f00; }
        pre { background: #222; padding: 10px; border-radius: 3px; overflow-x: auto; white-space: pre-wrap; font-size: 12px; }
        .summary { background: #222; padding: 20px; border-radius: 10px; margin: 20px 0; text-align: center; }
        .auth-info { background: #1a1a2e; padding: 15px; border-radius: 5px; margin: 15px 0; }
        .actions { text-align: center; margin: 30px 0; }
        .actions a { color: #0ff; text-decoration: none; margin: 0 15px; padding: 10px 20px; border: 1px solid #0ff; border-radius: 5px; display: inline-block; }
        .actions a:hover { background: #0ff; color: #000; }
    </style>
</head>
<body>
    <h1>🧪 Database Test Results v4.3.5</h1>
    
    <div class="summary">
        <h2>Test Summary for: "${testResults.slug}"</h2>
        <p><strong>Total Tests:</strong> ${testResults.tests.length}</p>
        <p><strong>Passed:</strong> ${testResults.tests.filter(t => t.status === 'SUCCESS').length}</p>
        <p><strong>Failed:</strong> ${testResults.tests.filter(t => t.status === 'FAILED').length}</p>
    </div>

    <div class="auth-info">
        <h2>Authentication Status</h2>
        <p><strong>User Authenticated:</strong> ${testResults.authentication.userAuthenticated ? '✅ YES' : '❌ NO'}</p>
        <p><strong>Methods Checked:</strong> ${testResults.authentication.methods}</p>
    </div>

    <h2>Detailed Test Results</h2>
    ${testSummary}

    <div class="actions">
        <a href="/">← Return to Portal</a>
        <a href="/api/health">Health Check</a>
        <a href="/admin">Admin Dashboard</a>
    </div>
</body>
</html>`;
}