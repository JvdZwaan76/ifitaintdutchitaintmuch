#!/bin/bash

# Dutch CMS Rollback Script
# Rolls back to previous version with automatic backup

set -e

if [ -z "$1" ]; then
    echo "❌ Error: Please provide backup timestamp"
    echo "Usage: ./rollback.sh <timestamp>"
    echo ""
    echo "Available backups:"
    ls -la backups/ | grep "backup-" | tail -5
    exit 1
fi

BACKUP_TIMESTAMP="$1"
BACKUP_DIR="./backups/pre-deploy-backup-$BACKUP_TIMESTAMP"
ROLLBACK_TIMESTAMP=$(date +%Y%m%d_%H%M%S)
CURRENT_BACKUP_DIR="./backups/pre-rollback-backup-$ROLLBACK_TIMESTAMP"

echo "🔄 Dutch CMS Rollback Script"
echo "============================"
echo "Rolling back to: $BACKUP_TIMESTAMP"

# Check if backup exists
if [ ! -d "$BACKUP_DIR" ]; then
    echo "❌ Error: Backup directory not found: $BACKUP_DIR"
    echo ""
    echo "Available backups:"
    ls -la backups/ | grep "backup-"
    exit 1
fi

echo "💾 Creating backup of current state before rollback..."
mkdir -p "$CURRENT_BACKUP_DIR"
cp src/worker.js "$CURRENT_BACKUP_DIR/"
cp wrangler.toml "$CURRENT_BACKUP_DIR/"
echo "Current state backup: $ROLLBACK_TIMESTAMP" > "$CURRENT_BACKUP_DIR/BACKUP_INFO.txt"

echo "⏪ Restoring files from backup..."
cp "$BACKUP_DIR/worker.js" src/
cp "$BACKUP_DIR/wrangler.toml" .

echo "🚀 Deploying rollback version..."
wrangler deploy

echo "✅ Rollback complete!"
echo ""
echo "🎯 Site restored to previous version"
echo "💾 Current state backed up to: $CURRENT_BACKUP_DIR"
echo "🔄 To undo this rollback: ./rollback.sh $ROLLBACK_TIMESTAMP"