#!/bin/bash

# Dutch CMS Staging Deployment Script
# Deploys to staging environment for testing

set -e

echo "🎛️ Dutch CMS Staging Deployment"
echo "==============================="

# Ensure we're using staging configuration
echo "🔄 Configuring for staging deployment..."

# Keep original worker name for staging
echo "📡 Deploying to staging: dutch-mystery-portal-api.agiajasper.workers.dev"

wrangler deploy

echo "✅ Staging deployment complete!"
echo ""
echo "🧪 Staging site: https://dutch-mystery-portal-api.agiajasper.workers.dev"
echo "📊 Staging admin: https://dutch-mystery-portal-api.agiajasper.workers.dev/admin"
echo ""
echo "🚀 When ready for production, run: ./deploy.sh"