/**
 * Dutch Mystery Portal - Complete Cloudflare Worker with Fixed Access Request Handler
 * Version: 3.8.1 - Fixed JSX syntax errors
 */

// CORS headers for cross-origin requests
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Session-Token, X-Admin-Key',
  'Access-Control-Max-Age': '86400',
};

const SESSION_DURATION = 24 * 60 * 60 * 1000; // 24 hours
const ADMIN_KEY = 'dutch-mystery-admin-2025';

export default {
  async fetch(request, env, ctx) {
    console.log('=== WORKER REQUEST START ===');
    console.log('Request URL:', request.url);
    console.log('Request method:', request.method);

    if (request.method === 'OPTIONS') {
      console.log('Handling OPTIONS request');
      return new Response(null, { status: 204, headers: corsHeaders });
    }

    try {
      const url = new URL(request.url);
      const path = url.pathname;
      console.log('Request path:', path);

      // Health check endpoint
      if (path === '/api/health' && request.method === 'GET') {
        console.log('Handling health check');
        return await handleHealthCheck(env);
      }

      // Blog content routes (main functionality)
      if (path.startsWith('/blog/') || path === '/ade-2025-guide') {
        console.log('Handling blog content request for path:', path);
        return await handleBlogContent(request, env);
      }

      // FIXED: Access request endpoint with proper date handling
      if (path === '/api/access-request' && request.method === 'POST') {
        console.log('Handling access request with FIXED date handler');
        return await handleAccessRequestFixed(request, env);
      }

      // Admin endpoints for request management
      if (path === '/api/requests' && request.method === 'GET') {
        return await handleGetRequests(request, env);
      }

      if (path === '/api/requests/update-status' && request.method === 'POST') {
        return await handleUpdateStatus(request, env);
      }

      if (path === '/api/requests/export' && request.method === 'GET') {
        return await handleExport(request, env);
      }

      if (path === '/api/stats' && request.method === 'GET') {
        return await handleStats(request, env);
      }

      // Admin dashboard
      if (path === '/admin' && request.method === 'GET') {
        console.log('Handling admin dashboard');
        return await handleAdminDashboard(request, env);
      }

      // Admin authentication routes
      if (path === '/api/admin/login' && request.method === 'POST') {
        console.log('Handling admin login');
        return await handleAdminLogin(request, env);
      }

      // Default 404 response
      console.log('No matching route found, returning 404');
      return new Response(JSON.stringify({ 
        error: 'Not Found', 
        path: path,
        availableRoutes: ['/api/health', '/ade-2025-guide', '/api/access-request', '/admin']
      }), {
        status: 404,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });

    } catch (error) {
      console.error('=== WORKER ERROR ===');
      console.error('Error message:', error.message);
      console.error('Error stack:', error.stack);
      console.error('Request URL:', request.url);
      
      return new Response(JSON.stringify({
        error: 'Internal Server Error',
        message: error.message,
        timestamp: new Date().toISOString()
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    }
  },
};

/**
 * FIXED VERSION: Access Request Handler with Proper Date Format for D1 TEXT Field
 */
async function handleAccessRequestFixed(request, env) {
  console.log('=== FIXED ACCESS REQUEST HANDLER START ===');
  console.log('Request method:', request.method);
  console.log('Request URL:', request.url);
  
  try {
    // Step 1: Check environment
    if (!env?.DB) {
      console.error('CRITICAL: Database binding missing');
      return new Response(JSON.stringify({
        error: 'Database Configuration Error',
        message: 'Database binding not found'
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    }
    
    // Step 2: Parse request body
    let body;
    try {
      const rawText = await request.text();
      if (!rawText.trim()) {
        throw new Error('Empty request body');
      }
      body = JSON.parse(rawText);
      console.log('Parsed body keys:', Object.keys(body || {}));
    } catch (parseError) {
      console.error('Body parsing failed:', parseError.message);
      return new Response(JSON.stringify({
        error: 'Request Parsing Error',
        message: parseError.message
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    }
    
    // Step 3: Basic validation
    const requiredFields = ['fullName', 'email', 'phone', 'country'];
    const missingFields = requiredFields.filter(field => !body[field] || !body[field].trim());
    
    if (missingFields.length > 0) {
      console.error('Missing required fields:', missingFields);
      return new Response(JSON.stringify({
        error: 'Validation Error',
        message: `Missing required fields: ${missingFields.join(', ')}`
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    }
    
    // Step 4: Check for duplicates
    try {
      const duplicateCheck = await env.DB.prepare(`
        SELECT id FROM access_requests 
        WHERE email = ? AND created_at > datetime('now', '-24 hours')
      `).bind(body.email.trim().toLowerCase()).first();

      if (duplicateCheck) {
        return new Response(JSON.stringify({
          error: 'Duplicate Request',
          message: 'An access request with this email was already submitted within the last 24 hours.'
        }), {
          status: 409,
          headers: { 'Content-Type': 'application/json', ...corsHeaders },
        });
      }
    } catch (duplicateError) {
      console.error('Duplicate check failed (non-blocking):', duplicateError.message);
    }
    
    // FIXED Step 5: Proper date formatting for TEXT field
    // The database expects request_date as TEXT in format "YYYY-MM-DD HH:MM:SS"
    const requestDate = body.requestDate ? new Date(body.requestDate) : new Date();
    
    // Format as "YYYY-MM-DD HH:MM:SS" for TEXT field
    const year = requestDate.getFullYear();
    const month = String(requestDate.getMonth() + 1).padStart(2, '0');
    const day = String(requestDate.getDate()).padStart(2, '0');
    const hours = String(requestDate.getHours()).padStart(2, '0');
    const minutes = String(requestDate.getMinutes()).padStart(2, '0');
    const seconds = String(requestDate.getSeconds()).padStart(2, '0');
    
    const formattedDate = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    console.log('Formatted request_date for TEXT field:', formattedDate);
    
    // Prepare sanitized data
    const insertData = {
      fullName: body.fullName.trim(),
      email: body.email.trim().toLowerCase(),
      phone: body.phone.trim(),
      country: body.country.trim(),
      requestDate: formattedDate, // TEXT format: "YYYY-MM-DD HH:MM:SS"
      userAgent: body.userAgent || null,
      referrer: body.referrer || null
    };
    
    console.log('Final insert data:', JSON.stringify(insertData, null, 2));
    
    try {
      // Execute the insert with properly formatted date
      const result = await env.DB.prepare(`
        INSERT INTO access_requests (
          full_name, 
          email, 
          phone, 
          country, 
          request_date, 
          user_agent, 
          referrer, 
          status, 
          created_at, 
          updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', datetime('now'), datetime('now'))
      `).bind(
        insertData.fullName,
        insertData.email,
        insertData.phone,
        insertData.country,
        insertData.requestDate, // Now properly formatted for TEXT field
        insertData.userAgent,
        insertData.referrer
      ).run();
      
      console.log('Insert result:', JSON.stringify(result, null, 2));
      
      if (!result.success) {
        throw new Error(`Insert failed: ${result.error || 'Unknown database error'}`);
      }
      
      if (!result.meta?.last_row_id) {
        throw new Error('Insert succeeded but no row ID returned');
      }
      
      console.log('SUCCESS: Access request inserted with ID:', result.meta.last_row_id);
      
      // Step 6: Send email notifications (non-blocking)
      try {
        await sendAdminNotification({
          full_name: insertData.fullName,
          email: insertData.email,
          phone: insertData.phone,
          country: insertData.country
        }, result.meta.last_row_id, env);
        console.log('Admin notification sent');
      } catch (emailError) {
        console.error('Admin notification failed (non-blocking):', emailError.message);
      }

      try {
        await sendUserConfirmation({
          full_name: insertData.fullName,
          email: insertData.email
        }, env);
        console.log('User confirmation sent');
      } catch (emailError) {
        console.error('User confirmation failed (non-blocking):', emailError.message);
      }
      
      return new Response(JSON.stringify({
        success: true,
        message: 'Access request submitted successfully',
        requestId: result.meta.last_row_id,
        debug: { 
          step: 'completed', 
          timestamp: new Date().toISOString(),
          formattedDate: formattedDate,
          insertedId: result.meta.last_row_id
        }
      }), {
        status: 201,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
      
    } catch (insertError) {
      console.error('=== INSERT ERROR DETAILS ===');
      console.error('Error message:', insertError.message);
      console.error('Data being inserted:', JSON.stringify(insertData, null, 2));
      
      return new Response(JSON.stringify({
        error: 'Database Insert Error',
        message: insertError.message,
        debug: { 
          step: 'insert', 
          insertData: insertData,
          formattedDate: formattedDate
        }
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    }
    
  } catch (error) {
    console.error('=== UNEXPECTED ERROR ===');
    console.error('Error message:', error.message);
    
    return new Response(JSON.stringify({
      error: 'Unexpected Server Error',
      message: error.message,
      debug: {
        step: 'unexpected_error',
        timestamp: new Date().toISOString()
      }
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    });
  }
}

/**
 * Blog Content Handler
 */
async function handleBlogContent(request, env) {
  console.log('=== BLOG CONTENT HANDLER START ===');
  
  try {
    const url = new URL(request.url);
    let slug = url.pathname;
    console.log('Original pathname:', slug);
    
    // Handle legacy route
    if (slug === '/ade-2025-guide') {
      slug = 'ade-2025-guide';
    } else if (slug.startsWith('/blog/')) {
      slug = slug.replace('/blog/', '');
    }
    
    console.log('Processed slug:', slug);

    // Check database binding
    if (!env.DB) {
      console.error('Database binding is missing!');
      return new Response('Database not configured', { 
        status: 500,
        headers: { 'Content-Type': 'text/plain' }
      });
    }

    console.log('Database binding exists, querying for blog post...');

    // Query for blog post
    const blogPost = await env.DB.prepare('SELECT * FROM blog_posts WHERE slug = ?').bind(slug).first();

    console.log('Database query completed');
    console.log('Blog post found:', !!blogPost);
    
    if (!blogPost) {
      console.log('No blog post found for slug:', slug);
      return new Response(generateNotFoundPage(slug), { 
        status: 404,
        headers: { 'Content-Type': 'text/html; charset=utf-8' }
      });
    }

    // Check authentication using HTTP cookies
    const authCookie = request.headers.get('Cookie') || '';
    const sessionAuth = request.headers.get('X-Session-Token') || '';
    
    console.log('Cookie header exists:', !!authCookie);
    console.log('Session token exists:', !!sessionAuth);
    
    // Check for authentication in multiple ways
    const hasAuthCookie = authCookie.includes('dutchPortalAuth=authenticated');
    const hasSessionToken = sessionAuth.length > 0;
    const hasAuth = hasAuthCookie || hasSessionToken;

    console.log('Authentication check:', { 
      hasAuthCookie, 
      hasSessionToken, 
      hasAuth
    });

    // ADE guide requires authentication for full content
    const requiresAuth = slug === 'ade-2025-guide';
    console.log('Requires auth:', requiresAuth);

    // Generate HTML content
    console.log('Generating HTML content...');
    const htmlContent = generateBlogHTML(blogPost, hasAuth, requiresAuth);
    console.log('HTML content generated, length:', htmlContent.length);

    // Track content view
    await trackContentView(request, env, hasAuth ? 'blog_post' : 'blog_preview', slug);

    console.log('=== BLOG CONTENT HANDLER SUCCESS ===');
    
    return new Response(htmlContent, {
      status: 200,
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'Cache-Control': 'public, max-age=300',
        ...corsHeaders,
      },
    });

  } catch (error) {
    console.error('=== BLOG CONTENT HANDLER ERROR ===');
    console.error('Error message:', error.message);
    console.error('Error stack:', error.stack);
    
    // Return detailed error page for debugging
    return new Response(generateErrorPage(error, request, env), {
      status: 500,
      headers: { 'Content-Type': 'text/html; charset=utf-8' },
    });
  }
}

/**
 * Handle status updates with email notifications + username/password generation
 */
async function handleUpdateStatus(request, env) {
  try {
    // Check admin authentication
    const adminKey = request.headers.get('X-Admin-Key');
    if (adminKey !== ADMIN_KEY) {
      return new Response(JSON.stringify({
        error: 'Unauthorized',
        message: 'Invalid admin credentials'
      }), {
        status: 401,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    }

    const body = await request.json();
    const { requestId, status, notes } = body;

    if (!requestId || !status) {
      return new Response(JSON.stringify({
        error: 'Missing required fields',
        message: 'requestId and status are required'
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    }

    if (!['pending', 'approved', 'rejected'].includes(status)) {
      return new Response(JSON.stringify({
        error: 'Invalid status',
        message: 'Status must be pending, approved, or rejected'
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    }

    // Get the current request for email notification
    const currentRequest = await env.DB.prepare(`
      SELECT * FROM access_requests WHERE id = ?
    `).bind(requestId).first();

    if (!currentRequest) {
      return new Response(JSON.stringify({
        error: 'Request not found',
        message: 'Access request not found'
      }), {
        status: 404,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    }

    // Generate username and password for approved users
    let username = null;
    let password = null;
    
    if (status === 'approved') {
      username = generateUsername(currentRequest.full_name);
      password = generatePassword();
      
      console.log(`Generated credentials for ${currentRequest.email}: ${username} / ${password}`);
    }

    // Update status with credentials if approved
    const updateQuery = status === 'approved' 
      ? `UPDATE access_requests 
         SET status = ?, notes = ?, username = ?, password = ?, updated_at = datetime('now')
         WHERE id = ?`
      : `UPDATE access_requests 
         SET status = ?, notes = ?, updated_at = datetime('now')
         WHERE id = ?`;

    const updateParams = status === 'approved' 
      ? [status, notes || null, username, password, requestId]
      : [status, notes || null, requestId];

    const result = await env.DB.prepare(updateQuery).bind(...updateParams).run();

    if (!result.success) {
      throw new Error('Failed to update status');
    }

    // Send status update email with credentials if approved
    try {
      await sendStatusUpdateEmail(currentRequest, status, notes, env, username, password);
    } catch (emailError) {
      console.error('Failed to send status update email:', emailError);
    }

    return new Response(JSON.stringify({
      success: true,
      message: 'Status updated successfully',
      credentials: status === 'approved' ? { username, password } : null
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    });

  } catch (error) {
    console.error('Error updating status:', error);
    return new Response(JSON.stringify({
      error: 'Server Error',
      message: 'Failed to update status'
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    });
  }
}

/**
 * Get access requests for admin
 */
async function handleGetRequests(request, env) {
  try {
    const url = new URL(request.url);
    const limit = Math.min(parseInt(url.searchParams.get('limit')) || 50, 100);
    const offset = Math.max(parseInt(url.searchParams.get('offset')) || 0, 0);
    const status = url.searchParams.get('status');

    let query = `
      SELECT id, full_name, email, phone, country, status, username, password,
             created_at, updated_at, notes
      FROM access_requests
    `;
    let params = [];

    if (status) {
      query += ' WHERE status = ?';
      params.push(status);
    }

    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(limit, offset);

    const { results } = await env.DB.prepare(query).bind(...params).all();

    const countQuery = status 
      ? 'SELECT COUNT(*) as total FROM access_requests WHERE status = ?'
      : 'SELECT COUNT(*) as total FROM access_requests';
    const countParams = status ? [status] : [];
    const { total } = await env.DB.prepare(countQuery).bind(...countParams).first();

    return new Response(JSON.stringify({
      data: results,
      pagination: {
        total: total,
        limit: limit,
        offset: offset,
        hasMore: offset + limit < total
      }
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    });

  } catch (error) {
    console.error('Error fetching requests:', error);
    return new Response(JSON.stringify({
      error: 'Server Error',
      message: 'Failed to fetch access requests'
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    });
  }
}

/**
 * Statistics endpoint
 */
async function handleStats(request, env) {
  try {
    const stats = await Promise.all([
      env.DB.prepare('SELECT COUNT(*) as total FROM access_requests').first(),
      env.DB.prepare('SELECT COUNT(*) as pending FROM access_requests WHERE status = "pending"').first(),
      env.DB.prepare('SELECT COUNT(*) as approved FROM access_requests WHERE status = "approved"').first(),
      env.DB.prepare('SELECT COUNT(*) as rejected FROM access_requests WHERE status = "rejected"').first(),
      env.DB.prepare('SELECT COUNT(*) as today FROM access_requests WHERE DATE(created_at) = DATE("now")').first(),
      env.DB.prepare('SELECT COUNT(*) as this_week FROM access_requests WHERE created_at >= datetime("now", "-7 days")').first(),
    ]);

    return new Response(JSON.stringify({
      total: stats[0].total,
      pending: stats[1].pending,
      approved: stats[2].approved,
      rejected: stats[3].rejected,
      today: stats[4].today,
      thisWeek: stats[5].this_week
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    });

  } catch (error) {
    console.error('Error getting stats:', error);
    return new Response(JSON.stringify({
      error: 'Failed to get statistics'
    }), { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
  }
}

/**
 * Export functionality
 */
async function handleExport(request, env) {
  try {
    const url = new URL(request.url);
    const format = url.searchParams.get('format') || 'json';
    const status = url.searchParams.get('status');

    let query = 'SELECT * FROM access_requests';
    let params = [];

    if (status) {
      query += ' WHERE status = ?';
      params.push(status);
    }

    query += ' ORDER BY created_at DESC';

    const { results } = await env.DB.prepare(query).bind(...params).all();

    if (format === 'csv') {
      const csv = convertToCSV(results);
      return new Response(csv, {
        status: 200,
        headers: {
          'Content-Type': 'text/csv',
          'Content-Disposition': 'attachment; filename="access_requests.csv"',
          ...corsHeaders,
        },
      });
    }

    return new Response(JSON.stringify({
      data: results,
      exportedAt: new Date().toISOString(),
      count: results.length
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    });

  } catch (error) {
    console.error('Error exporting data:', error);
    return new Response(JSON.stringify({
      error: 'Export failed'
    }), { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
  }
}

/**
 * Health Check Handler
 */
async function handleHealthCheck(env) {
  console.log('=== HEALTH CHECK HANDLER ===');
  
  try {
    // Test database connection
    const result = await env.DB.prepare('SELECT 1 as health').first();
    console.log('Database health check result:', result);
    
    // Test blog_posts table access with safe handling
    let blogPostsCount = 0;
    try {
      const tableTest = await env.DB.prepare('SELECT COUNT(*) as count FROM blog_posts').first();
      blogPostsCount = tableTest?.count || 0;
      console.log('Blog posts count:', blogPostsCount);
    } catch (countError) {
      console.log('Could not count blog posts:', countError.message);
    }
    
    return new Response(JSON.stringify({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      database: result ? 'connected' : 'disconnected',
      blogPostsCount: blogPostsCount,
      version: '3.8.1-fixed-jsx-errors',
      features: [
        'blog_authentication', 
        'enhanced_blog_layout',
        'fixed_access_requests',
        'preview_system', 
        'access_requests', 
        'email_notifications',
        'admin_dashboard',
        'status_management',
        'credential_generation',
        'resend_integration'
      ],
      emailConfigured: !!(env.RESEND_API_KEY && env.ADMIN_EMAIL)
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    });
  } catch (error) {
    console.error('Health check error:', error);
    return new Response(JSON.stringify({
      status: 'unhealthy',
      error: error?.message || 'Unknown error',
      timestamp: new Date().toISOString()
    }), {
      status: 503,
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    });
  }
}

/**
 * Admin Dashboard Handler
 */
async function handleAdminDashboard(request, env) {
  const html = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dutch Mystery Portal - Admin Dashboard</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1a1a1a, #2d1810);
            color: #fff;
            min-height: 100vh;
        }
        
        .header {
            background: rgba(255, 149, 0, 0.1);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255, 149, 0, 0.3);
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header h1 {
            color: #FF9500;
            font-size: 1.5rem;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            padding: 2rem;
        }
        
        .stat-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 149, 0, 0.3);
            border-radius: 10px;
            padding: 1.5rem;
            text-align: center;
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: #FF9500;
            margin-bottom: 0.5rem;
        }
        
        .stat-label {
            color: rgba(255, 255, 255, 0.8);
            font-size: 0.9rem;
        }
        
        .controls {
            padding: 0 2rem 1rem;
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
            align-items: center;
        }
        
        .btn {
            background: linear-gradient(135deg, #FF9500, #FFD700);
            color: #000;
            border: none;
            padding: 0.7rem 1.5rem;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            transition: transform 0.2s;
        }
        
        .btn:hover {
            transform: translateY(-2px);
        }
        
        .btn-secondary {
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
        }
        
        select, input {
            background: rgba(0, 0, 0, 0.6);
            border: 1px solid rgba(255, 149, 0, 0.3);
            color: #fff;
            padding: 0.7rem;
            border-radius: 5px;
        }
        
        .table-container {
            margin: 0 2rem 2rem;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
            overflow: hidden;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid rgba(255, 149, 0, 0.2);
        }
        
        th {
            background: rgba(255, 149, 0, 0.1);
            color: #FF9500;
            font-weight: 600;
        }
        
        .status {
            padding: 0.3rem 0.8rem;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .status.pending {
            background: rgba(255, 193, 7, 0.2);
            color: #FFC107;
        }
        
        .status.approved {
            background: rgba(40, 167, 69, 0.2);
            color: #28A745;
        }
        
        .status.rejected {
            background: rgba(220, 53, 69, 0.2);
            color: #DC3545;
        }
        
        .actions {
            display: flex;
            gap: 0.5rem;
        }
        
        .btn-small {
            padding: 0.4rem 0.8rem;
            font-size: 0.8rem;
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 1000;
        }
        
        .modal-content {
            background: #2d1810;
            margin: 10% auto;
            padding: 2rem;
            border-radius: 10px;
            width: 90%;
            max-width: 500px;
            border: 1px solid rgba(255, 149, 0, 0.3);
        }
        
        .close {
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            color: #FF9500;
        }
        
        .form-group {
            margin-bottom: 1rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: #FF9500;
        }
        
        .form-group textarea {
            width: 100%;
            min-height: 100px;
            background: rgba(0, 0, 0, 0.6);
            border: 1px solid rgba(255, 149, 0, 0.3);
            color: #fff;
            padding: 0.7rem;
            border-radius: 5px;
            resize: vertical;
        }
        
        .loading {
            display: none;
            text-align: center;
            padding: 2rem;
            color: #FF9500;
        }

        .credentials-display {
            background: rgba(0, 255, 0, 0.1);
            border: 1px solid rgba(0, 255, 0, 0.3);
            padding: 1rem;
            border-radius: 5px;
            margin: 1rem 0;
            font-family: monospace;
        }

        @media (max-width: 768px) {
            .controls {
                flex-direction: column;
                align-items: stretch;
            }
            
            .stats-grid {
                grid-template-columns: 1fr 1fr;
                padding: 1rem;
            }
            
            table {
                font-size: 0.9rem;
            }
            
            th, td {
                padding: 0.5rem;
            }
            
            .actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Dutch Mystery Portal - Admin Dashboard</h1>
        <button class="btn" onclick="refreshData()">Refresh Data</button>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-number" id="totalRequests">-</div>
            <div class="stat-label">Total Requests</div>
        </div>
        <div class="stat-card">
            <div class="stat-number" id="pendingRequests">-</div>
            <div class="stat-label">Pending</div>
        </div>
        <div class="stat-card">
            <div class="stat-number" id="approvedRequests">-</div>
            <div class="stat-label">Approved</div>
        </div>
        <div class="stat-card">
            <div class="stat-number" id="rejectedRequests">-</div>
            <div class="stat-label">Rejected</div>
        </div>
        <div class="stat-card">
            <div class="stat-number" id="todayRequests">-</div>
            <div class="stat-label">Today</div>
        </div>
        <div class="stat-card">
            <div class="stat-number" id="weekRequests">-</div>
            <div class="stat-label">This Week</div>
        </div>
    </div>

    <div class="controls">
        <select id="statusFilter" onchange="filterByStatus()">
            <option value="">All Statuses</option>
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
        </select>
        
        <input type="text" id="searchInput" placeholder="Search by name or email..." onkeyup="searchRequests()">
        
        <button class="btn" onclick="exportData()">Export CSV</button>
    </div>

    <div class="loading" id="loading">Loading requests...</div>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Country</th>
                    <th>Status</th>
                    <th>Credentials</th>
                    <th>Submitted</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="requestsTable">
            </tbody>
        </table>
    </div>

    <div id="statusModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h3>Update Request Status</h3>
            <form id="statusForm">
                <div class="form-group">
                    <label for="newStatus">Status:</label>
                    <select id="newStatus" required>
                        <option value="pending">Pending</option>
                        <option value="approved">Approved</option>
                        <option value="rejected">Rejected</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="statusNotes">Notes (optional):</label>
                    <textarea id="statusNotes" placeholder="Add any notes about this decision..."></textarea>
                </div>
                <div id="credentialsInfo" class="credentials-display" style="display: none;">
                    <strong>Generated Credentials (will be emailed to user):</strong><br>
                    <span id="generatedCredentials"></span>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn">Update Status</button>
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const ADMIN_KEY = 'dutch-mystery-admin-2025';
        let allRequests = [];
        let currentRequestId = null;

        async function loadStats() {
            try {
                const response = await fetch('/api/stats');
                const stats = await response.json();
                
                document.getElementById('totalRequests').textContent = stats.total || 0;
                document.getElementById('pendingRequests').textContent = stats.pending || 0;
                document.getElementById('approvedRequests').textContent = stats.approved || 0;
                document.getElementById('rejectedRequests').textContent = stats.rejected || 0;
                document.getElementById('todayRequests').textContent = stats.today || 0;
                document.getElementById('weekRequests').textContent = stats.thisWeek || 0;
            } catch (error) {
                console.error('Error loading stats:', error);
            }
        }

        async function loadRequests() {
            try {
                document.getElementById('loading').style.display = 'block';
                const response = await fetch('/api/requests?limit=100');
                const data = await response.json();
                allRequests = data.data || [];
                displayRequests(allRequests);
            } catch (error) {
                console.error('Error loading requests:', error);
                alert('Failed to load requests');
            } finally {
                document.getElementById('loading').style.display = 'none';
            }
        }

        function displayRequests(requests) {
            const tbody = document.getElementById('requestsTable');
            tbody.innerHTML = '';

            requests.forEach(function(request) {
                const row = document.createElement('tr');
                const date = new Date(request.created_at).toLocaleDateString();
                
                const credentials = request.username && request.password 
                    ? request.username + ' / ' + request.password
                    : (request.status === 'approved' ? 'Pending' : '-');
                
                row.innerHTML = 
                    '<td>' + request.id + '</td>' +
                    '<td>' + request.full_name + '</td>' +
                    '<td>' + request.email + '</td>' +
                    '<td>' + request.phone + '</td>' +
                    '<td>' + request.country + '</td>' +
                    '<td><span class="status ' + request.status + '">' + request.status + '</span></td>' +
                    '<td style="font-family: monospace; font-size: 0.8rem;">' + credentials + '</td>' +
                    '<td>' + date + '</td>' +
                    '<td class="actions">' +
                        '<button class="btn btn-small" onclick="openStatusModal(' + request.id + ', \\'' + request.status + '\\')">Update</button>' +
                        '<button class="btn btn-small btn-secondary" onclick="viewDetails(' + request.id + ')">View</button>' +
                    '</td>';
                tbody.appendChild(row);
            });
        }

        function filterByStatus() {
            const status = document.getElementById('statusFilter').value;
            const filtered = status ? allRequests.filter(function(r) { return r.status === status; }) : allRequests;
            displayRequests(filtered);
        }

        function searchRequests() {
            const query = document.getElementById('searchInput').value.toLowerCase();
            const filtered = allRequests.filter(function(r) {
                return r.full_name.toLowerCase().includes(query) || 
                       r.email.toLowerCase().includes(query);
            });
            displayRequests(filtered);
        }

        function openStatusModal(requestId, currentStatus) {
            currentRequestId = requestId;
            document.getElementById('newStatus').value = currentStatus;
            document.getElementById('statusNotes').value = '';
            document.getElementById('credentialsInfo').style.display = 'none';
            document.getElementById('statusModal').style.display = 'block';
            
            document.getElementById('newStatus').addEventListener('change', function() {
                if (this.value === 'approved') {
                    document.getElementById('credentialsInfo').style.display = 'block';
                    document.getElementById('generatedCredentials').textContent = 'Credentials will be auto-generated and emailed to user';
                } else {
                    document.getElementById('credentialsInfo').style.display = 'none';
                }
            });
        }

        function closeModal() {
            document.getElementById('statusModal').style.display = 'none';
            currentRequestId = null;
        }

        async function updateStatus(event) {
            event.preventDefault();
            
            if (!currentRequestId) return;

            const status = document.getElementById('newStatus').value;
            const notes = document.getElementById('statusNotes').value;

            try {
                const response = await fetch('/api/requests/update-status', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Admin-Key': ADMIN_KEY
                    },
                    body: JSON.stringify({
                        requestId: currentRequestId,
                        status: status,
                        notes: notes
                    })
                });

                const result = await response.json();

                if (response.ok) {
                    const message = 'Status updated successfully!' + 
                          (result.credentials ? ' Credentials generated: ' + result.credentials.username + ' / ' + result.credentials.password : '');
                    alert(message);
                    closeModal();
                    refreshData();
                } else {
                    alert('Error: ' + result.message);
                }
            } catch (error) {
                console.error('Error updating status:', error);
                alert('Failed to update status');
            }
        }

        async function exportData() {
            try {
                const status = document.getElementById('statusFilter').value;
                const url = status ? '/api/requests/export?format=csv&status=' + status : '/api/requests/export?format=csv';
                
                const response = await fetch(url);
                const csv = await response.text();
                
                const blob = new Blob([csv], { type: 'text/csv' });
                const url2 = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url2;
                a.download = 'access_requests.csv';
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url2);
                document.body.removeChild(a);
            } catch (error) {
                console.error('Error exporting data:', error);
                alert('Failed to export data');
            }
        }

        function viewDetails(requestId) {
            const request = allRequests.find(function(r) { return r.id === requestId; });
            if (!request) return;

            const credentials = request.username && request.password 
                ? 'Username: ' + request.username + '\\nPassword: ' + request.password
                : 'No credentials generated';

            alert(
                'Request Details:\\n\\n' +
                'ID: ' + request.id + '\\n' +
                'Name: ' + request.full_name + '\\n' +
                'Email: ' + request.email + '\\n' +
                'Phone: ' + request.phone + '\\n' +
                'Country: ' + request.country + '\\n' +
                'Status: ' + request.status + '\\n' +
                'Submitted: ' + new Date(request.created_at).toLocaleString() + '\\n' +
                'User Agent: ' + (request.user_agent || 'N/A') + '\\n' +
                'Referrer: ' + (request.referrer || 'N/A') + '\\n' +
                'Notes: ' + (request.notes || 'N/A') + '\\n\\n' +
                'Credentials:\\n' + credentials
            );
        }

        async function refreshData() {
            await Promise.all([loadStats(), loadRequests()]);
        }

        document.getElementById('statusForm').addEventListener('submit', updateStatus);

        window.onclick = function(event) {
            const modal = document.getElementById('statusModal');
            if (event.target === modal) {
                closeModal();
            }
        }

        refreshData();
    </script>
</body>
</html>`;

  return new Response(html, {
    headers: { 'Content-Type': 'text/html; charset=utf-8', ...corsHeaders },
  });
}

/**
 * Admin Login Handler
 */
async function handleAdminLogin(request, env) {
  try {
    const body = await request.json();
    const username = body?.username || '';
    const password = body?.password || '';
    
    console.log('Admin login attempt for username:', username);

    const validCredentials = [
      { username: 'admin', password: 'DutchMystery2025!' },
      { username: 'portal', password: 'Mystery2025' }
    ];

    const isValid = validCredentials.some(cred => 
      cred.username === username && cred.password === password
    );

    if (isValid) {
      const sessionId = crypto.randomUUID();
      console.log('Login successful, session created:', sessionId);
      
      return new Response(JSON.stringify({
        success: true,
        sessionToken: sessionId,
        user: { username: username, role: 'admin' },
        expiresAt: new Date(Date.now() + SESSION_DURATION).toISOString()
      }), {
        status: 200,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    } else {
      console.log('Login failed for username:', username);
      return new Response(JSON.stringify({
        error: 'Invalid credentials'
      }), {
        status: 401,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      });
    }
  } catch (error) {
    console.error('Admin login error:', error);
    return new Response(JSON.stringify({
      error: 'Login failed',
      message: error?.message || 'Unknown error'
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    });
  }
}

/**
 * Email notification functions
 */
async function sendAdminNotification(userData, requestId, env) {
  if (!env.RESEND_API_KEY || !env.ADMIN_EMAIL) {
    console.log('Email not configured - would send admin notification');
    return;
  }

  try {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + env.RESEND_API_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: 'Dutch Mystery Portal <portal@ifitaintdutchitaintmuch.com>',
        to: [env.ADMIN_EMAIL],
        subject: 'New Portal Access Request',
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: linear-gradient(135deg, #1a1a1a, #2d1810); color: #fff; padding: 20px; border-radius: 10px;">
            <div style="text-align: center; margin-bottom: 30px;">
              <h1 style="color: #FF9500; margin: 0; text-shadow: 0 0 10px #FF9500;">Dutch Mystery Portal</h1>
              <h2 style="color: #00BFFF; margin: 10px 0 0 0;">New Access Request</h2>
            </div>
            
            <div style="background: rgba(255, 149, 0, 0.1); border: 1px solid rgba(255, 149, 0, 0.3); border-radius: 8px; padding: 20px; margin: 20px 0;">
              <table style="width: 100%; color: #fff;">
                <tr><td style="padding: 8px 0; font-weight: bold; color: #FFD700;">Request ID:</td><td style="padding: 8px 0;">#${requestId}</td></tr>
                <tr><td style="padding: 8px 0; font-weight: bold; color: #FFD700;">Name:</td><td style="padding: 8px 0;">${userData.full_name}</td></tr>
                <tr><td style="padding: 8px 0; font-weight: bold; color: #FFD700;">Email:</td><td style="padding: 8px 0;">${userData.email}</td></tr>
                <tr><td style="padding: 8px 0; font-weight: bold; color: #FFD700;">Phone:</td><td style="padding: 8px 0;">${userData.phone}</td></tr>
                <tr><td style="padding: 8px 0; font-weight: bold; color: #FFD700;">Country:</td><td style="padding: 8px 0;">${userData.country}</td></tr>
                <tr><td style="padding: 8px 0; font-weight: bold; color: #FFD700;">Submitted:</td><td style="padding: 8px 0;">${new Date().toLocaleString()}</td></tr>
              </table>
            </div>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="https://ifitaintdutchitaintmuch.com/admin" 
                 style="background: linear-gradient(135deg, #FF9500, #FFD700); color: #000; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">
                Review in Admin Dashboard
              </a>
            </div>
            
            <div style="text-align: center; margin-top: 20px; color: rgba(255, 255, 255, 0.6); font-size: 12px;">
              <p>This email was sent automatically by the Dutch Mystery Portal system.</p>
            </div>
          </div>
        `
      })
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error('Email API error: ' + error);
    }

    console.log('Admin notification sent for request ' + requestId);
  } catch (error) {
    console.error('Failed to send admin notification:', error);
    throw error;
  }
}

async function sendUserConfirmation(userData, env) {
  if (!env.RESEND_API_KEY) {
    console.log('Email not configured - would send user confirmation');
    return;
  }

  try {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + env.RESEND_API_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: 'Dutch Mystery Portal <portal@ifitaintdutchitaintmuch.com>',
        to: [userData.email],
        subject: 'Your Dutch Mystery Portal Access Request Received',
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: linear-gradient(135deg, #1a1a1a, #2d1810); color: #fff; padding: 20px; border-radius: 10px;">
            <div style="text-align: center; margin-bottom: 30px;">
              <h1 style="color: #FF9500; margin: 0; text-shadow: 0 0 10px #FF9500;">Dutch Mystery Portal</h1>
              <h2 style="color: #00BFFF; margin: 10px 0 0 0;">Access Request Received</h2>
            </div>
            
            <div style="background: rgba(255, 149, 0, 0.1); border: 1px solid rgba(255, 149, 0, 0.3); border-radius: 8px; padding: 20px; margin: 20px 0;">
              <p style="color: #fff; line-height: 1.6; margin: 0 0 15px 0;">Dear <strong style="color: #FFD700;">${userData.full_name}</strong>,</p>
              
              <p style="color: #fff; line-height: 1.6; margin: 0 0 15px 0;">We've received your request to access the <strong style="color: #FF9500;">Dutch Mystery Portal</strong>. Our portal guardians will review your application and respond within <strong style="color: #00BFFF;">48 hours</strong>.</p>
              
              <p style="color: #fff; line-height: 1.6; margin: 0 0 15px 0;">You'll receive an email notification once your request has been processed.</p>
              
              <div style="background: rgba(0, 191, 255, 0.1); border-left: 4px solid #00BFFF; padding: 15px; margin: 20px 0; border-radius: 4px;">
                <p style="color: #00BFFF; margin: 0; font-style: italic;">"Enter the void if you dare... Dutch mysteries await the initiated."</p>
              </div>
            </div>
            
            <div style="text-align: center; margin: 30px 0;">
              <p style="color: rgba(255, 255, 255, 0.8); margin: 0;">Thank you for your interest in joining our mysterious realm!</p>
              <p style="color: #FF9500; font-weight: bold; margin: 10px 0 0 0;">The Dutch Mystery Portal Team</p>
            </div>
            
            <div style="text-align: center; margin-top: 20px; color: rgba(255, 255, 255, 0.6); font-size: 12px;">
              <p>This is an automated confirmation. Please do not reply to this email.</p>
            </div>
          </div>
        `
      })
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error('Email API error: ' + error);
    }

    console.log('Confirmation email sent to ' + userData.email);
  } catch (error) {
    console.error('Failed to send user confirmation:', error);
    throw error;
  }
}

async function sendStatusUpdateEmail(userData, newStatus, notes, env, username, password) {
  if (!env.RESEND_API_KEY) {
    console.log('Email not configured - would send status update');
    return;
  }

  const statusConfig = {
    approved: {
      subject: 'Welcome to the Dutch Mystery Portal! Your Access is Approved',
      color: '#28A745',
      title: 'Access Approved!',
      message: 'Congratulations! Your access request has been <strong style="color: #28A745;">approved</strong>. You now have access to our exclusive Dutch mysteries, premium merchandise, and underground Amsterdam experiences.'
    },
    rejected: {
      subject: 'Dutch Mystery Portal Access Decision',
      color: '#DC3545',
      title: 'Access Decision',
      message: 'Thank you for your interest in the Dutch Mystery Portal. Unfortunately, your access request was <strong style="color: #DC3545;">not approved</strong> at this time.'
    }
  };

  const config = statusConfig[newStatus];
  if (!config) return;

  let credentialsSection = '';
  let nextStepsSection = '';

  if (newStatus === 'approved' && username && password) {
    credentialsSection = `
      <div style="background: rgba(40, 167, 69, 0.1); border: 1px solid rgba(40, 167, 69, 0.3); border-radius: 8px; padding: 20px; margin: 20px 0;">
        <h3 style="color: #28A745; margin: 0 0 15px 0;">Your Login Credentials</h3>
        <div style="background: rgba(0, 0, 0, 0.3); padding: 15px; border-radius: 5px; font-family: monospace;">
          <p style="margin: 5px 0; color: #FFD700;"><strong>Username:</strong> ${username}</p>
          <p style="margin: 5px 0; color: #FFD700;"><strong>Password:</strong> ${password}</p>
        </div>
        <p style="color: #fff; margin-top: 15px; font-size: 14px;"><strong>Save these credentials safely!</strong> You'll need them to access premium content.</p>
      </div>`;
    
    nextStepsSection = `
      <div style="background: rgba(40, 167, 69, 0.1); border: 1px solid rgba(40, 167, 69, 0.3); border-radius: 8px; padding: 20px; margin: 20px 0;">
        <h3 style="color: #28A745; margin: 0 0 15px 0;">What's Next?</h3>
        <ul style="color: #fff; line-height: 1.6; margin: 0; padding-left: 20px;">
          <li>Visit our exclusive portal at <a href="https://ifitaintdutchitaintmuch.com" style="color: #FFD700;">ifitaintdutchitaintmuch.com</a></li>
          <li>Use the credentials above to access the full portal</li>
          <li>Explore our heritage collection and underground events</li>
          <li>Join our exclusive community of Dutch mystery enthusiasts</li>
        </ul>
      </div>`;
  } else if (newStatus === 'rejected') {
    nextStepsSection = `
      <div style="background: rgba(220, 53, 69, 0.1); border: 1px solid rgba(220, 53, 69, 0.3); border-radius: 8px; padding: 20px; margin: 20px 0;">
        <h3 style="color: #DC3545; margin: 0 0 15px 0;">Next Steps</h3>
        <p style="color: #fff; line-height: 1.6; margin: 0;">You're welcome to reapply in the future. Keep following our journey on social media for updates on when applications reopen.</p>
      </div>`;
  }

  let notesSection = '';
  if (notes) {
    notesSection = `
      <div style="background: rgba(255, 215, 0, 0.1); border-left: 4px solid #FFD700; padding: 15px; margin: 20px 0; border-radius: 4px;">
        <p style="color: #FFD700; margin: 0 0 5px 0; font-weight: bold;">Additional Notes:</p>
        <p style="color: #fff; margin: 0; font-style: italic;">${notes}</p>
      </div>`;
  }

  try {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + env.RESEND_API_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: 'Dutch Mystery Portal <portal@ifitaintdutchitaintmuch.com>',
        to: [userData.email],
        subject: config.subject,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: linear-gradient(135deg, #1a1a1a, #2d1810); color: #fff; padding: 20px; border-radius: 10px;">
            <div style="text-align: center; margin-bottom: 30px;">
              <h1 style="color: #FF9500; margin: 0; text-shadow: 0 0 10px #FF9500;">Dutch Mystery Portal</h1>
              <h2 style="color: ${config.color}; margin: 10px 0 0 0;">${config.title}</h2>
            </div>
            
            <div style="background: rgba(255, 149, 0, 0.1); border: 1px solid rgba(255, 149, 0, 0.3); border-radius: 8px; padding: 20px; margin: 20px 0;">
              <p style="color: #fff; line-height: 1.6; margin: 0 0 15px 0;">Dear <strong style="color: #FFD700;">${userData.full_name}</strong>,</p>
              <p style="color: #fff; line-height: 1.6; margin: 0 0 15px 0;">${config.message}</p>
              ${notesSection}
            </div>
            
            ${credentialsSection}
            ${nextStepsSection}
            
            <div style="text-align: center; margin: 30px 0;">
              <p style="color: #FF9500; font-weight: bold; margin: 0;">The Dutch Mystery Portal Team</p>
            </div>
            
            <div style="text-align: center; margin-top: 20px; color: rgba(255, 255, 255, 0.6); font-size: 12px;">
              <p>This is an automated notification. Please do not reply to this email.</p>
              ${newStatus === 'approved' ? '<p><strong>Keep your login credentials secure!</strong> You will not receive them again.</p>' : ''}
            </div>
          </div>
        `
      })
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error('Email API error: ' + error);
    }

    console.log('Status update email sent to ' + userData.email + ': ' + newStatus + (username ? ' with credentials ' + username : ''));
  } catch (error) {
    console.error('Failed to send status update email:', error);
    throw error;
  }
}

/**
 * Username and password generation functions
 */
function generateUsername(fullName) {
  const cleanName = fullName.toLowerCase()
    .replace(/[^a-z\s]/g, '')
    .trim()
    .split(' ')
    .filter(function(part) { return part.length > 0; });
  
  if (cleanName.length >= 2) {
    return cleanName[0] + cleanName[cleanName.length - 1].charAt(0) + Math.floor(Math.random() * 999).toString().padStart(3, '0');
  } else {
    return cleanName[0] + Math.floor(Math.random() * 9999).toString().padStart(4, '0');
  }
}

function generatePassword() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
  const symbols = '!@#$%&*';
  
  let password = '';
  
  password += chars.charAt(Math.floor(Math.random() * 23));
  password += chars.charAt(Math.floor(Math.random() * 25) + 25);
  password += chars.charAt(Math.floor(Math.random() * 8) + 50);
  password += symbols.charAt(Math.floor(Math.random() * symbols.length));
  
  for (let i = 4; i < 12; i++) {
    if (Math.random() > 0.8) {
      password += symbols.charAt(Math.floor(Math.random() * symbols.length));
    } else {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
  }
  
  return password.split('').sort(function() { return Math.random() - 0.5; }).join('');
}

/**
 * Utility functions
 */
function validateAccessRequest(data) {
  if (!data.fullName || typeof data.fullName !== 'string' || data.fullName.trim().length < 2) {
    return 'Full name is required and must be at least 2 characters';
  }

  if (!data.email || !isValidEmail(data.email)) {
    return 'Valid email address is required';
  }

  if (!data.phone || typeof data.phone !== 'string' || data.phone.trim().length < 8) {
    return 'Valid phone number is required';
  }

  if (!data.country || typeof data.country !== 'string' || data.country.trim().length < 2) {
    return 'Country selection is required';
  }

  if (data.fullName.length > 100) {
    return 'Full name must be less than 100 characters';
  }

  if (data.email.length > 150) {
    return 'Email address must be less than 150 characters';
  }

  if (data.phone.length > 20) {
    return 'Phone number must be less than 20 characters';
  }

  return null;
}

function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function sanitizeString(input) {
  if (typeof input !== 'string') return null;
  return input.trim().replace(/[<>]/g, '');
}

function sanitizeEmail(email) {
  if (typeof email !== 'string') return null;
  return email.trim().toLowerCase().replace(/[<>]/g, '');
}

function convertToCSV(data) {
  if (!data.length) return '';

  const headers = Object.keys(data[0]);
  const csvContent = [
    headers.join(','),
    ...data.map(function(row) {
      return headers.map(function(header) {
        const value = row[header];
        return typeof value === 'string' && value.includes(',') 
          ? '"' + value + '"'
          : value;
      }).join(',');
    })
  ].join('\n');

  return csvContent;
}

function safeString(value, fallback) {
  if (fallback === undefined) fallback = '';
  if (value === null || value === undefined) {
    return fallback;
  }
  return String(value);
}

function escapeHtml(text) {
  if (!text) return '';
  
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return String(text).replace(/[&<>"']/g, function(m) { return map[m]; });
}

async function trackContentView(request, env, contentType, contentId) {
  try {
    console.log('Content view tracked: ' + contentType + ' - ' + contentId);
  } catch (error) {
    console.error('Analytics tracking error:', error?.message || 'Unknown error');
  }
}

/**
 * Generate Blog HTML Page - Fixed template literals to avoid JSX syntax errors
 */
function generateBlogHTML(blogPost, hasAuth, requiresAuth) {
  console.log('Generating blog HTML with proper article layout...');
  
  const title = safeString(blogPost?.title, 'Dutch Mystery Portal');
  const metaDescription = safeString(blogPost?.meta_description, 'Exclusive content from the Dutch Mystery Portal');
  const author = safeString(blogPost?.author, 'Dutch Mystery Portal');
  const createdAt = blogPost?.created_at || new Date().toISOString();
  
  let displayContent;
  let isPreviewMode = requiresAuth && !hasAuth;
  
  if (isPreviewMode) {
    if (blogPost?.excerpt) {
      displayContent = blogPost.excerpt;
    } else if (blogPost?.content) {
      const content = blogPost.content;
      const paragraphs = content.split('</p>').slice(0, 3);
      displayContent = paragraphs.join('</p>') + (paragraphs.length > 0 ? '</p>' : '') + 
                      '<p style="color: #FFD700; font-style: italic; margin-top: 2rem;"><strong>Continue reading to unlock the complete guide...</strong></p>';
    } else {
      displayContent = '<p><em>Preview not available. Please log in to access the full content.</em></p>';
    }
  } else {
    displayContent = blogPost?.content || '<p><em>Content is currently being updated. Please check back soon.</em></p>';
  }
  
  const userAvatar = hasAuth ? 'M' : 'G';
  const userStatus = hasAuth ? 'authenticated' : 'guest';
  const userStatusText = hasAuth ? 'Authenticated' : 'Guest Access';
  const logoutButton = hasAuth ? '<button class="logout-btn" onclick="logout()">Logout</button>' : '';
  const previewBadge = isPreviewMode ? '<div class="preview-badge">Preview Mode - Login for Full Access</div>' : '';
  const statusIcon = isPreviewMode ? '&#128274;' : '&#9989;';
  const statusText = isPreviewMode ? 'Preview Mode' : 'Full Access';
  
  const loginCTA = isPreviewMode ? `
    <div class="login-cta">
        <h3 class="cta-title">Continue Reading in the Void</h3>
        <p class="cta-description">
            Unlock the complete <strong>${title}</strong> with exclusive insider information, 
            underground venues, hidden locations, and VIP access that only initiated members can access.
        </p>
        <div class="cta-buttons">
            <a href="/" class="cta-button">Login to Portal</a>
            <a href="/?focus=signup" class="cta-button secondary">Request Access</a>
        </div>
        <p style="margin-top: 1.5rem; font-size: 0.9rem; color: #888;">
            Join the Dutch mystery community and unlock exclusive content, underground events, and heritage collections.
        </p>
    </div>
  ` : '';

  return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title} | Dutch Mystery Portal</title>
    <meta name="description" content="${metaDescription}">
    
    <meta property="og:title" content="${title} | Dutch Mystery Portal">
    <meta property="og:description" content="${metaDescription}">
    <meta property="og:type" content="article">
    <meta property="og:image" content="https://ifitaintdutchitaintmuch.com/images/blog-default.jpg">
    
    <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600&family=Orbitron:wght@400;700;900&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary-orange: #FF9500;
            --electric-blue: #00BFFF;
            --neon-cyan: #00FFFF;
            --golden-yellow: #FFD700;
            --pure-black: #000000;
            --pure-white: #FFFFFF;
            --dark-gray: #111111;
            --font-title: 'Orbitron', Arial, sans-serif;
            --font-subtitle: 'Rajdhani', sans-serif;
            --font-body: 'Inter', Arial, sans-serif;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: var(--font-body);
            background: linear-gradient(135deg, var(--pure-black), var(--dark-gray));
            color: var(--pure-white);
            line-height: 1.7;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .background-gradient {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(ellipse 80% 50% at 20% 30%, rgba(255, 149, 0, 0.1) 0%, transparent 50%),
                radial-gradient(ellipse 60% 40% at 80% 70%, rgba(0, 191, 255, 0.08) 0%, transparent 50%),
                radial-gradient(ellipse 100% 80% at 40% 50%, rgba(107, 70, 193, 0.05) 0%, transparent 70%);
            z-index: -2;
            animation: etherealShift 20s infinite ease-in-out;
            pointer-events: none;
        }

        .floating-elements {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            pointer-events: none;
            overflow: hidden;
        }

        .nav-header {
            position: relative;
            z-index: 100;
            background: linear-gradient(145deg, rgba(255, 149, 0, 0.1), rgba(255, 149, 0, 0.05));
            backdrop-filter: blur(20px) saturate(180%);
            border-bottom: 1px solid rgba(255, 149, 0, 0.3);
            padding: 1rem 2rem;
        }

        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .nav-logo {
            font-family: var(--font-title);
            font-size: clamp(1.2rem, 3vw, 1.8rem);
            color: var(--primary-orange);
            text-shadow: 0 0 10px var(--primary-orange);
            text-decoration: none;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            transition: all 0.3s ease;
        }

        .nav-logo:hover {
            transform: scale(1.05);
            text-shadow: 0 0 20px var(--primary-orange);
        }

        .nav-menu {
            display: flex;
            gap: clamp(1rem, 3vw, 2rem);
            align-items: center;
            flex-wrap: wrap;
        }

        .nav-link {
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            font-family: var(--font-subtitle);
            font-size: clamp(0.9rem, 2vw, 1rem);
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .nav-link::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(0, 191, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .nav-link:hover::before {
            left: 100%;
        }

        .nav-link:hover {
            color: var(--electric-blue);
            background: rgba(0, 191, 255, 0.1);
            transform: translateY(-2px);
        }

        .nav-link.active {
            color: var(--golden-yellow);
            background: rgba(255, 215, 0, 0.1);
            border: 1px solid rgba(255, 215, 0, 0.3);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
            color: var(--golden-yellow);
            font-size: clamp(0.8rem, 1.8vw, 0.9rem);
        }

        .user-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-orange), var(--electric-blue));
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 0.8rem;
        }

        .user-status {
            padding: 0.3rem 0.8rem;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .user-status.authenticated {
            background: rgba(40, 167, 69, 0.2);
            color: #28A745;
        }

        .user-status.guest {
            background: rgba(255, 193, 7, 0.2);
            color: #FFC107;
        }

        .logout-btn {
            background: none;
            border: 1px solid rgba(255, 149, 0, 0.3);
            color: var(--primary-orange);
            padding: 0.3rem 0.8rem;
            border-radius: 6px;
            font-size: 0.8rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .logout-btn:hover {
            background: rgba(255, 149, 0, 0.1);
            transform: translateY(-1px);
        }

        .article-container {
            flex: 1;
            max-width: 1000px;
            margin: 0 auto;
            padding: 2rem;
            position: relative;
            z-index: 2;
        }

        .article-header {
            text-align: center;
            margin-bottom: 3rem;
            padding-bottom: 2rem;
            border-bottom: 2px solid rgba(255, 149, 0, 0.3);
        }

        .article-title {
            font-family: var(--font-title);
            font-size: clamp(2rem, 5vw, 3.5rem);
            color: var(--primary-orange);
            text-shadow: 0 0 30px rgba(255, 149, 0, 0.5);
            margin-bottom: 1rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-weight: 900;
            word-wrap: break-word;
            hyphens: auto;
            animation: titleGlow 4s ease-in-out infinite alternate;
        }

        .article-subtitle {
            font-size: clamp(1rem, 3vw, 1.3rem);
            color: var(--electric-blue);
            text-shadow: 0 0 10px var(--electric-blue);
            margin-bottom: 1.5rem;
            font-style: italic;
        }

        .article-meta {
            display: flex;
            justify-content: center;
            gap: 2rem;
            flex-wrap: wrap;
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.9rem;
            font-family: var(--font-subtitle);
        }

        .meta-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .meta-icon {
            color: var(--golden-yellow);
        }

        .article-content {
            font-size: 1.1rem;
            line-height: 1.8;
            color: rgba(255, 255, 255, 0.9);
            margin-bottom: 3rem;
        }

        .article-content h2 {
            color: var(--neon-cyan);
            font-family: var(--font-title);
            font-size: 1.8rem;
            margin: 2.5rem 0 1rem;
            text-shadow: 0 0 15px var(--neon-cyan);
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .article-content h3 {
            color: var(--golden-yellow);
            font-size: 1.4rem;
            margin: 2rem 0 0.8rem;
            text-shadow: 0 0 8px var(--golden-yellow);
        }

        .article-content p {
            margin-bottom: 1.5rem;
            text-align: justify;
        }

        .article-content ul, .article-content ol {
            margin: 1.5rem 0;
            padding-left: 2rem;
        }

        .article-content li {
            margin-bottom: 0.8rem;
            color: rgba(255, 255, 255, 0.85);
        }

        .article-content strong {
            color: var(--golden-yellow);
            font-weight: 600;
        }

        .article-content em {
            color: var(--electric-blue);
            font-style: italic;
        }

        .article-content a {
            color: var(--neon-cyan);
            text-decoration: none;
            border-bottom: 1px solid rgba(0, 255, 255, 0.3);
            transition: all 0.3s ease;
        }

        .article-content a:hover {
            border-bottom-color: var(--neon-cyan);
            text-shadow: 0 0 8px var(--neon-cyan);
        }

        .preview-badge {
            background: linear-gradient(135deg, rgba(255, 193, 7, 0.2), rgba(255, 193, 7, 0.1));
            border: 1px solid rgba(255, 193, 7, 0.4);
            border-radius: 25px;
            padding: 0.5rem 1rem;
            display: inline-block;
            margin-bottom: 2rem;
            font-size: 0.9rem;
            font-weight: 600;
            color: #FFC107;
        }

        .login-cta {
            background: linear-gradient(145deg, rgba(255, 149, 0, 0.1), rgba(255, 149, 0, 0.05));
            border: 2px solid rgba(255, 149, 0, 0.4);
            border-radius: 20px;
            padding: 3rem 2rem;
            text-align: center;
            margin: 4rem 0;
            backdrop-filter: blur(15px);
            position: relative;
            overflow: hidden;
        }

        .login-cta::before {
            content: '';
            position: absolute;
            top: -2px;
            left: -2px;
            right: -2px;
            bottom: -2px;
            background: linear-gradient(45deg, var(--primary-orange), var(--golden-yellow), var(--electric-blue));
            border-radius: 20px;
            z-index: -1;
            opacity: 0.3;
            animation: borderGlow 3s ease-in-out infinite;
        }

        .cta-title {
            color: var(--primary-orange);
            font-family: var(--font-title);
            font-size: 1.8rem;
            margin-bottom: 1rem;
            text-shadow: 0 0 20px var(--primary-orange);
        }

        .cta-description {
            color: #cccccc;
            margin-bottom: 2rem;
            font-size: 1.1rem;
            line-height: 1.6;
        }

        .cta-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }

        .cta-button {
            background: linear-gradient(135deg, var(--primary-orange), var(--golden-yellow));
            color: var(--pure-black);
            text-decoration: none;
            padding: 1rem 2rem;
            border-radius: 12px;
            font-weight: bold;
            font-size: 1rem;
            transition: all 0.3s ease;
            display: inline-block;
            min-width: 160px;
            text-align: center;
        }

        .cta-button:hover {
            transform: translateY(-3px) scale(1.05);
            box-shadow: 0 15px 35px rgba(255, 149, 0, 0.4);
        }

        .cta-button.secondary {
            background: linear-gradient(135deg, rgba(0, 191, 255, 0.2), rgba(0, 191, 255, 0.1));
            color: var(--electric-blue);
            border: 2px solid var(--electric-blue);
        }

        .article-footer {
            border-top: 1px solid rgba(255, 149, 0, 0.3);
            padding: 2rem 0;
            text-align: center;
            margin-top: 4rem;
        }

        .footer-links {
            display: flex;
            justify-content: center;
            gap: 2rem;
            flex-wrap: wrap;
            margin-bottom: 1rem;
        }

        .footer-links a {
            color: var(--primary-orange);
            text-decoration: none;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .footer-links a:hover {
            color: var(--electric-blue);
            text-shadow: 0 0 10px var(--electric-blue);
        }

        .copyright {
            color: rgba(255, 255, 255, 0.6);
            font-size: 0.8rem;
            margin-top: 1rem;
        }

        @keyframes titleGlow {
            0% { 
                text-shadow: 0 0 20px var(--primary-orange);
            }
            100% { 
                text-shadow: 0 0 35px var(--primary-orange), 0 0 50px rgba(255, 149, 0, 0.8);
            }
        }

        @keyframes etherealShift {
            0%, 100% { opacity: 1; transform: scale(1); }
            33% { opacity: 0.8; transform: scale(1.05) rotate(1deg); }
            66% { opacity: 0.9; transform: scale(0.95) rotate(-1deg); }
        }

        @keyframes borderGlow {
            0%, 100% { opacity: 0.3; }
            50% { opacity: 0.6; }
        }

        @media (max-width: 1024px) {
            .nav-container {
                padding: 0 1rem;
            }
            
            .article-container {
                padding: 1.5rem;
            }
            
            .article-meta {
                flex-direction: column;
                gap: 0.5rem;
            }
        }

        @media (max-width: 768px) {
            .nav-container {
                flex-direction: column;
                text-align: center;
                gap: 0.5rem;
            }
            
            .nav-menu {
                justify-content: center;
            }
            
            .article-container {
                padding: 1rem;
            }
            
            .login-cta {
                padding: 2rem 1rem;
            }
            
            .cta-buttons {
                flex-direction: column;
                align-items: center;
            }
            
            .footer-links {
                flex-direction: column;
                gap: 1rem;
            }
        }

        @media (max-width: 480px) {
            .nav-header {
                padding: 1rem;
            }
            
            .user-info {
                font-size: 0.8rem;
            }
            
            .article-content {
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>
    <div class="background-gradient"></div>
    <div class="floating-elements"></div>

    <header class="nav-header">
        <nav class="nav-container">
            <a href="/" class="nav-logo">Dutch Mystery Portal</a>
            
            <div class="nav-menu">
                <a href="/" class="nav-link">Portal Home</a>
                <a href="/ade-2025-guide" class="nav-link active">ADE 2025 Guide</a>
                <a href="#" class="nav-link" onclick="alert('More content coming soon!')">Underground Events</a>
                <a href="#" class="nav-link" onclick="alert('More content coming soon!')">Heritage Collection</a>
                <a href="/admin" class="nav-link">Admin</a>
            </div>

            <div class="user-info">
                <div class="user-avatar">${userAvatar}</div>
                <span class="user-status ${userStatus}">
                    ${userStatusText}
                </span>
                ${logoutButton}
            </div>
        </nav>
    </header>

    <main class="article-container">
        <header class="article-header">
            ${previewBadge}
            <h1 class="article-title">${title}</h1>
            <p class="article-subtitle">Navigate Amsterdam's Underground Electronic Scene</p>
            <div class="article-meta">
                <div class="meta-item">
                    <span class="meta-icon">&#128100;</span>
                    <span>By ${author}</span>
                </div>
                <div class="meta-item">
                    <span class="meta-icon">&#128197;</span>
                    <span>${new Date(createdAt).toLocaleDateString()}</span>
                </div>
                <div class="meta-item">
                    <span class="meta-icon">${statusIcon}</span>
                    <span>${statusText}</span>
                </div>
            </div>
        </header>

        <article class="article-content">
            ${displayContent}
        </article>

        ${loginCTA}

        <footer class="article-footer">
            <div class="footer-links">
                <a href="/">Portal Home</a>
                <a href="/privacy-policy.html">Privacy Policy</a>
                <a href="/contact.html">Contact Portal</a>
                <a href="/admin">Admin Dashboard</a>
            </div>
            <div class="copyright">
                &copy; 2025 If It Ain't Dutch, It Ain't Much. All mysteries reserved.
            </div>
        </footer>
    </main>

    <script>
        function logout() {
            sessionStorage.removeItem('dutchPortalAuth');
            sessionStorage.removeItem('dutchPortalUser');
            sessionStorage.removeItem('dutchPortalTime');
            sessionStorage.removeItem('dutchPortalSession');
            
            document.cookie = 'dutchPortalAuth=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
            document.cookie = 'dutchPortalUser=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
            document.cookie = 'dutchPortalSession=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
            
            setTimeout(() => {
                window.location.href = '/';
            }, 500);
        }

        function createFloatingElements() {
            const container = document.querySelector('.floating-elements');
            if (!container) return;
            
            const symbols = ['🌷', '🛠️', '⚡', '🔮', '💎', '🌟', '🎭', '🗝️'];
            
            for (let i = 0; i < 8; i++) {
                const element = document.createElement('div');
                element.textContent = symbols[Math.floor(Math.random() * symbols.length)];
                element.style.cssText = \`
                    position: absolute;
                    font-size: \${Math.random() * 15 + 10}px;
                    opacity: \${Math.random() * 0.3 + 0.1};
                    pointer-events: none;
                    left: \${Math.random() * 100}%;
                    top: \${Math.random() * 100}%;
                    animation: floatMystery \${Math.random() * 20 + 15}s infinite linear;
                    will-change: transform;
                \`;
                container.appendChild(element);
            }
        }

        const style = document.createElement('style');
        style.textContent = \`
            @keyframes floatMystery {
                0% { transform: translateY(0) rotate(0deg) translateX(0); }
                25% { transform: translateY(-20px) rotate(90deg) translateX(10px); }
                50% { transform: translateY(-10px) rotate(180deg) translateX(-10px); }
                75% { transform: translateY(-30px) rotate(270deg) translateX(5px); }
                100% { transform: translateY(0) rotate(360deg) translateX(0); }
            }
        \`;
        document.head.appendChild(style);

        document.addEventListener('DOMContentLoaded', function() {
            createFloatingElements();
        });
    </script>
</body>
</html>`;
}

/**
 * Generate 404 Not Found Page
 */
function generateNotFoundPage(slug) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Content Not Found | Dutch Mystery Portal</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #000, #1a1a1a);
            color: #fff;
            text-align: center;
            padding: 50px 20px;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            max-width: 600px;
        }
        h1 {
            color: #FF9500;
            font-size: 3rem;
            margin-bottom: 20px;
            text-shadow: 0 0 20px rgba(255, 149, 0, 0.5);
        }
        p {
            font-size: 1.2rem;
            margin-bottom: 30px;
            color: #ccc;
        }
        .back-link {
            background: linear-gradient(135deg, #FF9500, #FFD700);
            color: #000;
            text-decoration: none;
            padding: 15px 30px;
            border-radius: 8px;
            font-weight: bold;
            display: inline-block;
        }
        .debug {
            margin-top: 40px;
            padding: 20px;
            background: rgba(255, 0, 0, 0.1);
            border: 1px solid rgba(255, 0, 0, 0.3);
            border-radius: 8px;
            font-family: monospace;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 Content Not Found</h1>
        <p>The mysterious content you seek has vanished into the void...</p>
        <p>The requested slug "<strong>` + safeString(slug, 'unknown') + `</strong>" does not exist in our database.</p>
        
        <a href="/" class="back-link">Return to Portal</a>
        
        <div class="debug">
            <strong>Debug Info:</strong><br>
            Requested Slug: ` + safeString(slug, 'unknown') + `<br>
            Database Query: SELECT * FROM blog_posts WHERE slug = ?<br>
            Debug Version: ✅ Active<br>
            Timestamp: ` + new Date().toISOString() + `
        </div>
    </div>
</body>
</html>`;
}

/**
 * Generate Error Page
 */
function generateErrorPage(error, request, env) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Error | Dutch Mystery Portal</title>
    <style>
        body {
            font-family: 'Courier New', monospace;
            background: #000;
            color: #fff;
            padding: 20px;
            line-height: 1.6;
        }
        .container {
            max-width: 1000px;
            margin: 0 auto;
        }
        h1 {
            color: #ff0000;
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 30px;
            text-shadow: 0 0 20px rgba(255, 0, 0, 0.5);
        }
        .error-section {
            background: rgba(51, 0, 0, 0.3);
            border: 2px solid #ff0000;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
        }
        .error-section h3 {
            color: #ffaa00;
            margin-bottom: 15px;
        }
        pre {
            background: #222;
            padding: 15px;
            border-radius: 5px;
            overflow: auto;
            white-space: pre-wrap;
            word-wrap: break-word;
            font-size: 12px;
        }
        .back-link {
            display: inline-block;
            background: #ff9500;
            color: #000;
            padding: 15px 25px;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
            margin-top: 20px;
        }
        .info-grid {
            display: grid;
            grid-template-columns: auto 1fr;
            gap: 10px 20px;
            font-size: 14px;
        }
        .label {
            color: #ffaa00;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>⚠️ System Error Detected</h1>
        
        <div class="error-section">
            <h3>Error Details</h3>
            <div class="info-grid">
                <span class="label">Message:</span>
                <span>` + safeString(error?.message, 'Unknown error') + `</span>
                <span class="label">URL:</span>
                <span>` + safeString(request?.url, 'Unknown URL') + `</span>
                <span class="label">Method:</span>
                <span>` + (request?.method || 'Unknown') + `</span>
                <span class="label">Timestamp:</span>
                <span>` + new Date().toISOString() + `</span>
            </div>
        </div>

        <div class="error-section">
            <h3>Stack Trace</h3>
            <pre>` + safeString(error?.stack, 'No stack trace available') + `</pre>
        </div>

        <div class="error-section">
            <h3>Environment Check</h3>
            <div class="info-grid">
                <span class="label">Database Binding:</span>
                <span>` + (env?.DB ? '✅ Available' : '❌ Missing') + `</span>
                <span class="label">Debug Mode:</span>
                <span>✅ Active with Enhanced Logging</span>
                <span class="label">Environment Keys:</span>
                <span>` + (env ? Object.keys(env).join(', ') : 'No environment') + `</span>
            </div>
        </div>

        <a href="/" class="back-link">← Return to Portal</a>
    </div>
</body>
</html>`;
}