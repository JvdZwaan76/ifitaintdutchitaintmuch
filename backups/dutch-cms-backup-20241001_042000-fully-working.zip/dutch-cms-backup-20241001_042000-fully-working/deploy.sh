#!/bin/bash

# Dutch CMS Deployment Script
# Deploys to your main domain: ifitaintdutchitaintmuch.com

set -e

echo "🎛️ Dutch CMS Deployment Script"
echo "==============================="

# Get current timestamp
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="./backups/pre-deploy-backup-$TIMESTAMP"

echo "📦 Creating pre-deployment backup..."
mkdir -p "$BACKUP_DIR"

# Backup current worker.js with version info
cp src/worker.js "$BACKUP_DIR/"
cp wrangler.toml "$BACKUP_DIR/"
echo "Backup created: $TIMESTAMP" > "$BACKUP_DIR/BACKUP_INFO.txt"
echo "Pre-deployment backup for main domain deployment" >> "$BACKUP_DIR/BACKUP_INFO.txt"

echo "🔄 Updating worker name for main domain..."
# Update worker name in wrangler.toml for main domain
sed -i.bak 's/name = "dutch-mystery-portal-api"/name = "ifitaintdutchitaintmuch-com"/' wrangler.toml

echo "🌍 Updating site URLs for production domain..."
# Update all URLs in worker.js to point to main domain
sed -i.bak 's|https://dutch-mystery-portal-api.agiajasper.workers.dev|https://ifitaintdutchitaintmuch.com|g' src/worker.js

echo "🚀 Deploying to Cloudflare Workers..."
wrangler deploy

echo "✅ Deployment complete!"
echo ""
echo "🎯 Your site is now live at: https://ifitaintdutchitaintmuch.com"
echo "📊 Admin dashboard: https://ifitaintdutchitaintmuch.com/admin"
echo "📝 Access requests: https://ifitaintdutchitaintmuch.com/api/access-request"
echo ""
echo "💾 Backup created in: $BACKUP_DIR"
echo "🔄 To rollback, run: ./rollback.sh $TIMESTAMP"

# Clean up temporary files
rm wrangler.toml.bak src/worker.js.bak 2>/dev/null || true